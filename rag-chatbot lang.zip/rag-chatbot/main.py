from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import chromadb
from sentence_transformers import SentenceTransformer
import ollama

# ----------------------------
# FastAPI App
# ----------------------------

app = FastAPI()

# Static files
app.mount("/static", StaticFiles(directory="templates/static"), name="static")

# Templates
templates = Jinja2Templates(directory="templates")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------------------
# ChromaDB
# ----------------------------

client = chromadb.PersistentClient(path="./chroma_db")

collection = client.get_collection("book_collection")

print("Total Chunks in DB:", collection.count())

# ----------------------------
# Embedding Model
# ----------------------------

model = SentenceTransformer("all-MiniLM-L6-v2")

# ----------------------------
# Request Model
# ----------------------------

class Question(BaseModel):
    question: str

# ----------------------------
# Home Page
# ----------------------------

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html"
    )

# ----------------------------
# Ask Endpoint
# ----------------------------

@app.post("/ask")
def ask_question(data: Question):

    print("\nQuestion:", data.question)

    query_embedding = model.encode(data.question).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=5
    )

    print("\nRetrieved Chunks:\n")

    for i, doc in enumerate(results["documents"][0], start=1):
        print(f"\n------ Chunk {i} ------\n")
        print(doc)

    context = "\n".join(results["documents"][0])

    prompt = f"""
You are a helpful assistant.

Use ONLY the information from the context below.

Context:
{context}

Question:
{data.question}

Answer:
"""

    response = ollama.chat(
        model="gemma3",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    answer = response["message"]["content"]

    print("\nGenerated Answer:\n")
    print(answer)

    return {
        "answer": answer
    }