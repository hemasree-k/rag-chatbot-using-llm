from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_ollama import ChatOllama
from langchain_classic.chains import RetrievalQA

# --------------------------------
# FastAPI
# --------------------------------

app = FastAPI()

app.mount(
    "/static",
    StaticFiles(directory="templates/static"),
    name="static"
)

templates = Jinja2Templates(directory="templates")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --------------------------------
# Embeddings
# --------------------------------

embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# --------------------------------
# ChromaDB
# --------------------------------

vectorstore = Chroma(
    persist_directory="./chroma_db_langchain",
    embedding_function=embeddings
)

# --------------------------------
# Retriever
# --------------------------------

retriever = vectorstore.as_retriever(
    search_kwargs={"k": 5}
)

# --------------------------------
# Gemma 3
# --------------------------------

llm = ChatOllama(
    model="gemma3"
)

# --------------------------------
# QA Chain
# --------------------------------

qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type="stuff"
)

# --------------------------------
# Request Model
# --------------------------------

class Question(BaseModel):
    question: str

# --------------------------------
# Home Page
# --------------------------------

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="index.html"
    )

# --------------------------------
# Ask Endpoint
# --------------------------------

@app.post("/ask")
def ask_question(data: Question):

    result = qa_chain.invoke(
        {"query": data.question}
    )

    return {
        "answer": result["result"]
    }