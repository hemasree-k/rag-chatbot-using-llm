from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import chromadb

# Load PDF
reader = PdfReader("data/book.pdf")

text = ""

for page in reader.pages:
    page_text = page.extract_text()
    if page_text:
        text += page_text

# Create Chunks
splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)

chunks = splitter.split_text(text)

print("Total chunks:", len(chunks))

# Load Embedding Model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Create Chroma Client
client = chromadb.PersistentClient(path="./chroma_db")

collection = client.get_or_create_collection(
    name="book_collection"
)

# Store Chunks
for i, chunk in enumerate(chunks):
    embedding = model.encode(chunk).tolist()

    collection.add(
        ids=[str(i)],
        embeddings=[embedding],
        documents=[chunk]
    )

print("Stored successfully in Chroma!")
print(collection.count())