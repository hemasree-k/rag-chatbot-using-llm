import chromadb
from sentence_transformers import SentenceTransformer
import ollama

# Connect ChromaDB
client = chromadb.PersistentClient(path="./chroma_db")

collection = client.get_collection("book_collection")

# Embedding Model
model = SentenceTransformer("all-MiniLM-L6-v2")

while True:

    question = input("\nAsk Question: ")

    if question.lower() == "exit":
        break

    # Convert question to vector
    query_embedding = model.encode(question).tolist()

    # Retrieve top chunks
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=3
    )

    context = "\n".join(results["documents"][0])

    prompt = f"""
You are a helpful assistant.

Answer ONLY from the provided context.

Context:
{context}

Question:
{question}
"""

    response = ollama.chat(
        model="gemma3",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    print("\nAnswer:")
    print(response["message"]["content"])